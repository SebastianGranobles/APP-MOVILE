package com.example.parcial_sebastiangranoblesardila

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Indication
import androidx.compose.foundation.LocalIndication
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.tooling.preview.Preview
// --> INICIO DE LA CORRECCIÓN <--
// El import ahora apunta al Composable correcto, que está en el paquete 'presentation'.
import com.example.parcial_sebastiangranoblesardila.presentation.AppNavigationController
// --> FIN DE LA CORRECCIÓN <--
import com.example.parcial_sebastiangranoblesardila.ui.theme.Parcial_SebastianGranoblesArdilaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Parcial_SebastianGranoblesArdilaTheme {
                // Forzamos a que toda la aplicación use la implementación de Ripple de Material3.
                // Esto soluciona el conflicto entre las librerías 'material' y 'material3'.
                val rippleIndication: Indication = rememberRipple()
                CompositionLocalProvider(LocalIndication provides rippleIndication) {
                    Surface(color = MaterialTheme.colorScheme.background) {
                        // --> CORRECCIÓN: Llamamos al Composable correcto: AppNavigationController()
                        AppNavigationController()
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    Parcial_SebastianGranoblesArdilaTheme {
        // También aplicamos el 'fix' a la previsualización para consistencia.
        val rippleIndication: Indication = rememberRipple()
        CompositionLocalProvider(LocalIndication provides rippleIndication) {
            Surface(color = MaterialTheme.colorScheme.background) {
                // --> CORRECCIÓN: Llamamos al Composable correcto aquí también.
                AppNavigationController()
            }
        }
    }
}