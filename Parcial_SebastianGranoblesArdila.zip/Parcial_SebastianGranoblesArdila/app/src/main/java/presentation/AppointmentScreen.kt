package com.example.parcial_sebastiangranoblesardila.presentation

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.navigation.NavController
import com.example.parcial_sebastiangranoblesardila.viewmodel.Appointment
import com.example.parcial_sebastiangranoblesardila.viewmodel.UserViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AppointmentScreen(navController: NavController, userViewModel: UserViewModel) {
    val context = LocalContext.current
    val AppRed = Color(0xFFC62828)
    val AppLightRed = Color(0xFFFDF7F7)
    val scrollState = rememberScrollState()

    val user by userViewModel.user.collectAsState()
    val userRole = user?.role ?: "ASESOR"

    // --- LÓGICA DE CÁMARA Y PERMISOS ---
    var tempUri by remember { mutableStateOf<Uri?>(null) }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            Toast.makeText(context, "Foto capturada correctamente", Toast.LENGTH_SHORT).show()
            // Aquí llamarías a: userViewModel.uploadPhoto(tempUri)
        }
    }

    val requestPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            val uri = createPhotoUri(context)
            tempUri = uri
            cameraLauncher.launch(uri)
        } else {
            Toast.makeText(context, "Permiso de cámara denegado", Toast.LENGTH_SHORT).show()
        }
    }

    val textFieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = AppRed,
        focusedTextColor = Color.Black,
        unfocusedTextColor = Color.Black,
        focusedLabelColor = AppRed,
        cursorColor = Color.Black,
        focusedContainerColor = Color.White,
        unfocusedContainerColor = Color.White
    )

    val servicePrices = mapOf(
        "Cambio de aceite" to 0.0, "Cambio de filtros" to 0.0, "Ajuste y lubricación de cadena" to 0.0, "Revisión general" to 0.0, "Mantenimiento preventivo" to 0.0,
        "Reparación de motor" to 0.0, "Ajuste de válvulas" to 0.0, "Cambio de kit de arrastre" to 0.0, "Cambio de embrague" to 0.0, "Reparación de fugas de aceite" to 0.0,
        "Cambio de pastillas" to 0.0, "Purgado de frenos" to 0.0, "Cambio de líquido de frenos" to 0.0, "Reparación de bomba / cáliper" to 0.0,
        "Diagnóstico eléctrico" to 0.0, "Cambio de batería" to 0.0, "Reparación de cableado" to 0.0, "Revisión sistema de carga" to 0.0, "Instalación de accesorios" to 0.0,
        "Limpieza de carburador" to 0.0, "Limpieza de inyectores" to 0.0, "Diagnóstico de inyección electrónica" to 0.0, "Cambio de filtro de combustible" to 0.0,
        "Cambio de retenes" to 0.0, "Mantenimiento de horquilla" to 0.0, "Cambio de llantas" to 0.0, "Parcheo / balanceo" to 0.0, "Cambio de rodamientos" to 0.0,
        "Diagnóstico por escáner" to 0.0, "Revisión pre-viaje" to 0.0, "Revisión para tecnomecánica" to 0.0, "Lavado de motor" to 0.0, "Personalización básica" to 0.0
    )

    // ESTADOS
    var plate by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var displacement by remember { mutableStateOf("") }
    var mileage by remember { mutableStateOf("") }
    var usageType by remember { mutableStateOf("Uso diario") }
    var clientName by remember { mutableStateOf("") }
    var phone1 by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    val selectedServices = remember { mutableStateListOf<String>() }
    var problemDescription by remember { mutableStateOf("") }
    var laborCost by remember { mutableStateOf("") }
    var selectedMechanic by remember { mutableStateOf("") }

    val mechanicsList = listOf("Sebastian Granobles", "Andrés Mendoza", "Juan Perez", "Carlos Rodriguez")

    val plateRegex = Regex("^[A-Z]{3}[0-9]{2}[A-Z]{1}$")
    val isPlateValid = plateRegex.matches(plate)
    val isPhoneValid = phone1.length == 10

    val totalToPay = (laborCost.toDoubleOrNull() ?: 0.0) + selectedServices.sumOf { servicePrices[it] ?: 0.0 }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("ORDEN DE ENTRADA", color = Color.White, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = AppRed),
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(AppLightRed)
                .verticalScroll(scrollState)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionTitle("1. DATOS DE LA MOTO")

            OutlinedTextField(
                value = plate,
                onValueChange = { if (it.length <= 6) plate = it.uppercase() },
                label = { Text("Placa * (Ej: ABC12H)") },
                modifier = Modifier.fillMaxWidth(),
                colors = textFieldColors,
                textStyle = TextStyle(color = Color.Black),
                isError = plate.isNotEmpty() && !isPlateValid
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = brand, onValueChange = { brand = it },
                    label = { Text("Marca") }, modifier = Modifier.weight(1f),
                    colors = textFieldColors, textStyle = TextStyle(color = Color.Black)
                )
                OutlinedTextField(
                    value = model, onValueChange = { model = it },
                    label = { Text("Referencia") }, modifier = Modifier.weight(1f),
                    colors = textFieldColors, textStyle = TextStyle(color = Color.Black)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = displacement, onValueChange = { displacement = it },
                    label = { Text("Cilindraje") }, modifier = Modifier.weight(1f),
                    colors = textFieldColors, textStyle = TextStyle(color = Color.Black),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(
                    value = year, onValueChange = { if (it.length <= 4) year = it },
                    label = { Text("Año") }, modifier = Modifier.weight(1f),
                    colors = textFieldColors, textStyle = TextStyle(color = Color.Black),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }

            OutlinedTextField(
                value = mileage, onValueChange = { mileage = it },
                label = { Text("Kilometraje Actual") }, modifier = Modifier.fillMaxWidth(),
                colors = textFieldColors, textStyle = TextStyle(color = Color.Black),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )

            Text("Tipo de uso:", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Trabajo", "Uso diario", "Alto cilindraje", "Otro").forEach { type ->
                    val isSelected = usageType == type
                    FilterChip(
                        selected = isSelected,
                        onClick = { usageType = type },
                        label = { Text(type, color = if (isSelected) Color.White else Color.Black) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AppRed,
                            containerColor = Color.Transparent
                        )
                    )
                }
            }

            SectionTitle("2. DATOS DEL CLIENTE")
            OutlinedTextField(value = clientName, onValueChange = { clientName = it }, label = { Text("Nombre Completo *") }, modifier = Modifier.fillMaxWidth(), colors = textFieldColors, textStyle = TextStyle(color = Color.Black))
            OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Correo Electrónico") }, modifier = Modifier.fillMaxWidth(), colors = textFieldColors, textStyle = TextStyle(color = Color.Black))

            OutlinedTextField(
                value = phone1,
                onValueChange = { if (it.length <= 10 && it.all { c -> c.isDigit() }) phone1 = it },
                label = { Text("Celular (10 dígitos) *") },
                modifier = Modifier.fillMaxWidth(),
                colors = textFieldColors,
                textStyle = TextStyle(color = Color.Black),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                trailingIcon = {
                    if (isPhoneValid) {
                        IconButton(onClick = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone1"))
                            context.startActivity(intent)
                        }) {
                            Icon(Icons.Default.Call, contentDescription = "Llamar", tint = Color(0xFF4CAF50))
                        }
                    }
                }
            )

            SectionTitle("3. SERVICIOS Y SÍNTOMAS")

            ServiceCategory("🛠️ MANTENIMIENTO", listOf("Cambio de aceite", "Cambio de filtros", "Ajuste y lubricación de cadena", "Revisión general", "Mantenimiento preventivo"), selectedServices, AppRed)
            ServiceCategory("🔧 MECÁNICA", listOf("Reparación de motor", "Ajuste de válvulas", "Cambio de kit de arrastre", "Cambio de embrague", "Reparación de fugas de aceite"), selectedServices, AppRed)
            ServiceCategory("⚙️ FRENOS", listOf("Cambio de pastillas", "Purgado de frenos", "Cambio de líquido de frenos", "Reparación de bomba / cáliper"), selectedServices, AppRed)
            ServiceCategory("🔌 ELÉCTRICO", listOf("Diagnóstico eléctrico", "Cambio de batería", "Reparación de cableado", "Revisión sistema de carga", "Instalación de accesorios"), selectedServices, AppRed)

            OutlinedTextField(
                value = problemDescription,
                onValueChange = { problemDescription = it },
                label = { Text("Descripción/Síntomas") },
                modifier = Modifier.fillMaxWidth().height(100.dp),
                colors = textFieldColors,
                textStyle = TextStyle(color = Color.Black)
            )

            SectionTitle("4. COSTOS Y MECÁNICO")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = laborCost, onValueChange = { laborCost = it },
                    label = { Text("Mano Obra ($)") }, modifier = Modifier.weight(1f),
                    colors = textFieldColors, textStyle = TextStyle(color = Color.Black),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(
                    value = String.format("%,.0f", totalToPay - (laborCost.toDoubleOrNull() ?: 0.0)),
                    onValueChange = {}, label = { Text("Repuestos") },
                    modifier = Modifier.weight(1f), readOnly = true,
                    colors = textFieldColors, textStyle = TextStyle(color = Color.Black)
                )
            }

            AppointmentDropdown(
                label = "Mecánico Asignado *",
                options = mechanicsList,
                onSelect = { selectedMechanic = it }
            )

            SectionTitle("5. REGISTRO FOTOGRÁFICO")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PhotoStepItem(
                    label = "INGRESO",
                    roleRequired = "ASESOR",
                    currentRole = userRole,
                    onTakePhoto = { requestPermissionLauncher.launch(Manifest.permission.CAMERA) },
                    modifier = Modifier.weight(1f)
                )
                PhotoStepItem(
                    label = "PROCESO",
                    roleRequired = "MECANICO",
                    currentRole = userRole,
                    onTakePhoto = { requestPermissionLauncher.launch(Manifest.permission.CAMERA) },
                    modifier = Modifier.weight(1f)
                )
                PhotoStepItem(
                    label = "FINALIZAR",
                    roleRequired = "MECANICO",
                    currentRole = userRole,
                    onTakePhoto = { requestPermissionLauncher.launch(Manifest.permission.CAMERA) },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    val now = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
                    val newAppointment = Appointment(
                        clientName = "$clientName | $usageType",
                        phone1 = phone1,
                        plate = plate,
                        brand = brand,
                        model = model,
                        displacement = displacement,
                        year = year,
                        mileage = mileage,
                        mechanic = selectedMechanic,
                        problemDescription = "Uso: $usageType | $problemDescription",
                        selectedServices = selectedServices.toList(),
                        laborCost = laborCost.toDoubleOrNull() ?: 0.0,
                        partsCost = totalToPay - (laborCost.toDoubleOrNull() ?: 0.0),
                        totalCost = totalToPay,
                        entryDate = now,
                        status = "En Taller"
                    )
                    userViewModel.addAppointment(newAppointment)
                    navController.popBackStack()
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                enabled = isPlateValid && clientName.isNotEmpty() && isPhoneValid && selectedMechanic.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = AppRed),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("GENERAR ORDEN DE SERVICIO", fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// --- FUNCIONES DE APOYO ---

@Composable
fun PhotoStepItem(
    label: String,
    roleRequired: String,
    currentRole: String,
    onTakePhoto: () -> Unit,
    modifier: Modifier = Modifier
) {
    val canUpload = currentRole == roleRequired || currentRole == "ADMIN"

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFF5F5F5))
            .border(1.dp, Color.LightGray, RoundedCornerShape(12.dp))
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = label, fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
        Spacer(Modifier.height(4.dp))
        IconButton(
            onClick = onTakePhoto,
            enabled = canUpload,
            modifier = Modifier.size(32.dp)
        ) {
            Icon(
                imageVector = Icons.Default.AddAPhoto,
                contentDescription = null,
                tint = if (canUpload) Color.DarkGray else Color.LightGray
            )
        }
        Text(text = if (canUpload) "SUBIR" else "BLOQUEADO", fontSize = 7.sp, color = Color.Gray)
    }
}

private fun createPhotoUri(context: Context): Uri {
    val directory = File(context.cacheDir, "photos").apply { mkdirs() }
    val file = File.createTempFile("IMG_${System.currentTimeMillis()}", ".jpg", directory)
    val authority = "com.example.parcial_sebastiangranoblesardila.fileprovider"
    return FileProvider.getUriForFile(context, authority, file)
}

@Composable
fun SectionTitle(title: String) {
    Text(title, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Color.Black)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ServiceCategory(title: String, services: List<String>, selectedServices: MutableList<String>, accentColor: Color) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.DarkGray)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            services.forEach { service ->
                val isSelected = selectedServices.contains(service)
                FilterChip(
                    selected = isSelected,
                    onClick = { if (isSelected) selectedServices.remove(service) else selectedServices.add(service) },
                    label = { Text(service, color = if (isSelected) Color.White else Color.Black) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = accentColor)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppointmentDropdown(label: String, options: List<String>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    var selectedText by remember { mutableStateOf("") }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = selectedText, onValueChange = {}, readOnly = true, label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                focusedTextColor = Color.Black, unfocusedTextColor = Color.Black
            )
        )
        ExposedDropdownMenu(
            expanded = expanded, onDismissRequest = { expanded = false },
            modifier = Modifier.background(Color.White)
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option, color = Color.Black) },
                    onClick = {
                        selectedText = option
                        onSelect(option)
                        expanded = false
                    },
                    modifier = Modifier.background(Color.White)
                )
            }
        }
    }
}