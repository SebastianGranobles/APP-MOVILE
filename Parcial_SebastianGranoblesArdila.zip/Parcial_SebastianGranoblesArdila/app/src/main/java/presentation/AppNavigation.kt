package com.example.parcial_sebastiangranoblesardila.presentation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.parcial_sebastiangranoblesardila.presentation.viewmodel.AuthState
import com.example.parcial_sebastiangranoblesardila.presentation.viewmodel.UserViewModel

/**
 * Este es el Composable principal que se llama desde MainActivity.
 * Contiene la lógica para mostrar el SplashScreen o la navegación principal.
 */
@Composable
fun AppNavigationController() {
    val userViewModel: UserViewModel = viewModel()

    // 1. Leemos el estado 'isSessionLoading' para saber si la sesión inicial ya se verificó.
    val isSessionLoading by userViewModel.isSessionLoading.collectAsState()

    // 2. Si la sesión inicial todavía está cargando, mostramos un indicador de carga.
    if (isSessionLoading) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
    } else {
        // 3. Si la carga de la sesión terminó, preparamos y llamamos al NavHost.
        val navController = rememberNavController()
        val authState by userViewModel.authState.collectAsState()

        AppNavHost(
            navController = navController,
            userViewModel = userViewModel,
            authState = authState
        )
    }
}

/**
 * Este Composable contiene únicamente el NavHost y la definición de las rutas.
 * Ha sido separado para mayor claridad y organización del código.
 */
@Composable
fun AppNavHost(
    navController: NavHostController,
    userViewModel: UserViewModel,
    authState: AuthState
) {
    NavHost(
        navController = navController,
        // La ruta de inicio se decide aquí, basándose en si el usuario está autenticado o no.
        startDestination = if (authState == AuthState.SUCCESS) "main_route" else "login_route"
    ) {
        composable("login_route") {
            LoginScreen(navController = navController, userViewModel = userViewModel)
        }
        composable("main_route") {
            MainScreen(navController = navController, userViewModel = userViewModel)
        }
        composable("user_route") {
            UserScreen(navController = navController, userViewModel = userViewModel)
        }
        composable("profile_route") {
            ProfileScreen(navController = navController, userViewModel = userViewModel)
        }
        composable("recover_password_route") {
            RecuperarContraseñaScreen(navController = navController, userViewModel = userViewModel)
        }
        composable("password_history_route") {
            PasswordHistoryScreen(navController = navController, userViewModel = userViewModel)
        }
    }
}