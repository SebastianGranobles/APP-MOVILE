package com.example.parcial_sebastiangranoblesardila.presentation

import android.util.Log // <-- IMPORTANTE: Añade esta línea
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.parcial_sebastiangranoblesardila.model.User
import com.example.parcial_sebastiangranoblesardila.presentation.viewmodel.UserViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(navController: NavController, userViewModel: UserViewModel) {
    val userState by userViewModel.user.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ajustes de Perfil") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                }
            )
        }
    ) { innerPadding ->
        val currentUser = userState
        if (currentUser == null) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            ProfileContent(
                modifier = Modifier.padding(innerPadding),
                user = currentUser,
                userViewModel = userViewModel,
                navController = navController
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProfileContent(
    modifier: Modifier = Modifier,
    user: User,
    userViewModel: UserViewModel,
    navController: NavController
) {
    val isLocked = userViewModel.isProfileEditingLocked
    val nationalities = userViewModel.nationalities

    var phone by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var selectedNationality by remember { mutableStateOf("") }

    LaunchedEffect(user) {
        phone = user.phone
        age = user.age
        city = user.city
        selectedNationality = user.nationality.ifEmpty { nationalities.firstOrNull() ?: "" }
    }

    var profileImageUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var remainingTime by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()

    val imagePickerLauncher = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: android.net.Uri? ->
        profileImageUri = uri
    }

    LaunchedEffect(isLocked, user) {
        if (isLocked) {
            val lastUpdate = user.lastProfileUpdateTime
            if (lastUpdate > 0) {
                val lockEndTime = lastUpdate + TimeUnit.HOURS.toMillis(3)
                while (System.currentTimeMillis() < lockEndTime) {
                    val remainingMillis = lockEndTime - System.currentTimeMillis()
                    if (remainingMillis <= 0) break
                    val hours = TimeUnit.MILLISECONDS.toHours(remainingMillis)
                    val minutes = TimeUnit.MILLISECONDS.toMinutes(remainingMillis) % 60
                    val seconds = TimeUnit.MILLISECONDS.toSeconds(remainingMillis) % 60
                    remainingTime = String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds)
                    delay(1000)
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ... (El resto del código de la UI no cambia)
        Box(
            modifier = Modifier
                .size(150.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.secondaryContainer)
                .clickable { if (!isLocked) imagePickerLauncher.launch("image/*") },
            contentAlignment = Alignment.Center
        ) {
            if (profileImageUri != null) {
                AsyncImage(model = profileImageUri, contentDescription = "Foto de perfil", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Icon(painter = rememberVectorPainter(Icons.Default.Person), contentDescription = "Icono de perfil", modifier = Modifier.size(80.dp), tint = MaterialTheme.colorScheme.onSecondaryContainer)
            }
        }
        Text("Toca la imagen para cambiarla", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
        Spacer(modifier = Modifier.height(24.dp))

        Text(user.fullName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(user.email, style = MaterialTheme.typography.bodyLarge)
        HorizontalDivider(modifier = Modifier.padding(vertical = 24.dp))

        if (isLocked) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("EDICIÓN BLOQUEADA", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                    Spacer(Modifier.height(8.dp))
                    Text("Podrás editar de nuevo en:", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                    Text(remainingTime, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
        }

        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Teléfono") }, modifier = Modifier.fillMaxWidth(), enabled = !isLocked, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = age, onValueChange = { age = it }, label = { Text("Edad") }, modifier = Modifier.fillMaxWidth(), isError = age.isNotEmpty() && (age.toIntOrNull() ?: 0) < 18, enabled = !isLocked, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("Ciudad de Residencia") }, modifier = Modifier.fillMaxWidth(), enabled = !isLocked)
        Spacer(modifier = Modifier.height(8.dp))

        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { if (!isLocked) expanded = !expanded }) {
            OutlinedTextField(value = selectedNationality, onValueChange = {}, readOnly = true, label = { Text("Nacionalidad") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth(), enabled = !isLocked)
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                nationalities.forEach { nationality ->
                    DropdownMenuItem(text = { Text(nationality) }, onClick = { selectedNationality = nationality; expanded = false })
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))

        if (errorMessage != null) {
            Text(errorMessage!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 8.dp))
        }
        if (successMessage != null) {
            Text(successMessage!!, color = Color(0xFF2E7D32), modifier = Modifier.padding(bottom = 8.dp))
        }

        // --> INICIO DE LA CORRECCIÓN CON LOGS <--
        Button(
            onClick = {
                Log.d("ProfileScreen", "Botón GUARDAR CAMBIOS pulsado.")

                val ageInt = age.toIntOrNull()
                if (phone.isBlank() || age.isBlank() || city.isBlank() || selectedNationality.isBlank()) {
                    errorMessage = "Todos los campos son obligatorios."
                    successMessage = null
                    Log.e("ProfileScreen", "Error: Campos obligatorios vacíos. Tel: '$phone', Edad: '$age', Ciudad: '$city', Nac: '$selectedNationality'")
                } else if (ageInt == null || ageInt < 18) {
                    errorMessage = "Debes ser mayor de 18 años."
                    successMessage = null
                    Log.e("ProfileScreen", "Error: Edad inválida. Valor ingresado: '$age'")
                } else {
                    Log.d("ProfileScreen", "Validación superada. Llamando a updateUserInfo...")
                    userViewModel.updateUserInfo(phone, age, city, selectedNationality)
                    successMessage = "¡Perfil actualizado con éxito!"
                    errorMessage = null
                    coroutineScope.launch { delay(3000); successMessage = null }
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            enabled = !isLocked
        ) {
            Text("GUARDAR CAMBIOS")
        }
        // --> FIN DE LA CORRECCIÓN CON LOGS <--

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
            onClick = { showDeleteDialog = true },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error)
        ) {
            Text("BORRAR CUENTA")
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Confirmar Borrado de Cuenta") },
            text = { Text("¿Estás seguro? Esta acción es irreversible y se borrarán todos tus datos.") },
            confirmButton = {
                Button(
                    onClick = {
                        userViewModel.deleteAccount()
                        showDeleteDialog = false
                        navController.navigate("login_route") { popUpTo(navController.graph.startDestinationId) { inclusive = true } }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("SÍ, BORRAR") }
            },
            dismissButton = { TextButton(onClick = { showDeleteDialog = false }) { Text("CANCELAR") } }
        )
    }
}