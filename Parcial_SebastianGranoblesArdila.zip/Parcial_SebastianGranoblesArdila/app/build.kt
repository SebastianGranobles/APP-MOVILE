// ... dentro de la sección dependencies { ... }

// Añade esta línea para tener acceso a todos los íconos de Material (Icons.Filled, Icons.Outlined, etc.)
implementation("androidx.compose.material:material-icons-extended")

// ... resto de tus dependencias
